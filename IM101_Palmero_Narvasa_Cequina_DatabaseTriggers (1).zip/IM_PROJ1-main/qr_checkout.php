<?php
declare(strict_types=1);

require __DIR__ . '/bootstrap.php';
require __DIR__ . '/config.php';

$order_id = filter_input(INPUT_GET, 'order_id', FILTER_VALIDATE_INT);
if (!$order_id || $order_id < 1) {
    http_response_code(400);
    exit('Invalid order number.');
}

try {
    $pdo = create_database_connection();
    $statement = $pdo->prepare(
        'SELECT order_id, product_name, sku, customer_name, quantity, unit_price, order_status, created_at '
        . 'FROM customer_orders WHERE order_id = :order_id'
    );
    $statement->execute(['order_id' => $order_id]);
    $order = $statement->fetch();
} catch (PDOException $exception) {
    error_log('QR Ph checkout could not load order: ' . $exception->getMessage());
    http_response_code(503);
    exit('The order is temporarily unavailable. Please try again later.');
}

if (!$order) {
    http_response_code(404);
    exit('Order not found.');
}

$total = (float) $order['unit_price'] * (int) $order['quantity'];

?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>QR Ph Payment | JLP Store</title>
    <link rel="stylesheet" href="styles.css">
    <style>
        .qrph-brand{display:flex;align-items:center;justify-content:center;gap:.75rem;margin:1.25rem auto .5rem}
        .qrph-logo{display:block;width:min(300px,78%);height:auto;object-fit:contain}
        .demo-pill{font-size:.72rem;font-weight:800;letter-spacing:.08em;padding:.3rem .55rem;border-radius:999px;background:#fff3cd;color:#805b00;border:1px solid #f0d98b}
        .qr-demo-card{width:min(300px,100%);margin:1rem auto;padding:1rem;border:1px solid #e2e8f0;border-radius:16px;background:#fff;text-align:center}
        .qr-demo-image{display:block;width:100%;max-width:250px;height:auto;margin:0 auto}
        .qr-demo-caption{margin:.75rem 0 0;font-size:.72rem;font-weight:800;letter-spacing:.08em;color:#64748b}
    </style>
</head>
<body>
<header>
    <div>
        <h1>JLP Store</h1>
        <p>QR Ph payment</p>
    </div>
    <a class="header-link" href="index.php">Back to store</a>
</header>
<main>
    <section class="panel" aria-labelledby="payment-heading">
        <div class="panel-heading">
            <h2 id="payment-heading">Complete your QR Ph payment</h2>
            <p>Order #<?= escape_html($order['order_id']) ?></p>
        </div>
        <?php if ($order['order_status'] === 'paid'): ?>
            <div class="notice success" role="status">Payment has been confirmed. Thank you for your purchase.</div>
        <?php elseif ($order['order_status'] !== 'pending'): ?>
            <div class="notice error" role="status">This order is <?= escape_html($order['order_status']) ?>. Please contact the store administrator if you need help.</div>
        <?php else: ?>
            <p>QR Ph payment demo. This screen is for demonstrating the checkout flow only; the sample code cannot accept or process payments.</p>
            <div class="qrph-brand" aria-label="QR Ph demo branding">
                <img src="qrph-logo.svg" alt="QR Ph logo" class="qrph-logo">
                <span class="demo-pill">DEMO</span>
            </div>
            <div class="qr-demo-card">
                <img src="qrph-demo-code.svg" alt="Decorative sample QR-style graphic, not scannable" class="qr-demo-image">
                <p class="qr-demo-caption">SAMPLE QR CODE · NOT SCANNABLE</p>
            </div>
            <p><strong>Product:</strong> <?= escape_html($order['product_name']) ?></p>
            <p><strong>SKU:</strong> <?= escape_html($order['sku']) ?></p>
            <p><strong>Quantity:</strong> <?= escape_html($order['quantity']) ?></p>
            <p><strong>Total to pay:</strong> ₱<?= escape_html(number_format($total, 2)) ?></p>
            <p><strong>Status:</strong> Pending verification</p>
            <p>This is a visual demo only. No real transfer can be made from this sample QR. In a real store, payment must be verified before an order is marked paid.</p>
        <?php endif; ?>
        <p><a class="header-link" href="index.php">Return to store</a></p>
    </section>
</main>
</body>
</html>
